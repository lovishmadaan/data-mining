# col761_assign2
Data Mining Assignment 2

DBSCAN parameters on dataset:
    minPts = 40
    epsilon = 0.35

0-30000
34490-46027
46346-59100
59425-79525
79990-84145
84530-91890
92220-99225