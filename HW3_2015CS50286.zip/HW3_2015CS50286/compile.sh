#!/bin/bash
g++-7 -std=c++11 isomorph.cpp -O3 -o getFT -fopenmp
chmod +x fsg